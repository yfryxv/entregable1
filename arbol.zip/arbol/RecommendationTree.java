import java.util.ArrayList;
import java.util.List;

// Clase Nodo para representar cada elemento del árbol
class TreeNode {
    private String value;  // Valor del nodo
    private List<TreeNode> children;  // Lista de hijos

    // Constructor
    public TreeNode(String value) {
        this.value = value;
        this.children = new ArrayList<>();
    }

    // Método para agregar un hijo
    public void addChild(TreeNode child) {
        children.add(child);
    }

    // Método para obtener los hijos
    public List<TreeNode> getChildren() {
        return children;
    }

    // Método para mostrar el árbol recursivamente
    public void displayTree(String prefix) {
        System.out.println(prefix + value); // Muestra el valor del nodo
        for (TreeNode child : children) {
            child.displayTree(prefix + "  "); // Llama recursivamente con indentación
        }
    }
}

// Clase principal para probar el árbol
public class RecommendationTree {
    public static void main(String[] args) {
        // Crear nodos raíz y secundarios
        TreeNode root = new TreeNode("Contenido");
        TreeNode movies = new TreeNode("Películas");
        TreeNode series = new TreeNode("Series");
        
        // Agregar subcategorías
        TreeNode actionMovies = new TreeNode("Acción");
        TreeNode comedyMovies = new TreeNode("Comedia");
        TreeNode dramaSeries = new TreeNode("Drama");
        TreeNode sciFiSeries = new TreeNode("Ciencia Ficción");

        // Construir el árbol
        root.addChild(movies);
        root.addChild(series);
        movies.addChild(actionMovies);
        movies.addChild(comedyMovies);
        series.addChild(dramaSeries);
        series.addChild(sciFiSeries);

        // Agregar elementos finales (hojas)
        actionMovies.addChild(new TreeNode("Mad Max"));
        comedyMovies.addChild(new TreeNode("Superbad"));
        dramaSeries.addChild(new TreeNode("Breaking Bad"));
        sciFiSeries.addChild(new TreeNode("Black Mirror"));

        // Mostrar el árbol
        root.displayTree("");
    }
}