class TreeNode:
    def __init__(self, value):
        """
        Inicializa un nodo de árbol con un valor y una lista de hijos.
        :param value: Valor del nodo.
        """
        self.value = value
        self.children = []

    def add_child(self, child_node):
        """
        Agrega un nodo hijo al nodo actual.
        :param child_node: Nodo que se agregará como hijo.
        """
        self.children.append(child_node)

    def display_tree(self, level=0):
        """
        Imprime el árbol en una estructura jerárquica usando recursividad.
        :param level: Nivel del nodo en el árbol (para identación).
        """
        print("  " * level + str(self.value))  # Imprime el valor del nodo con indentación
        for child in self.children:
            child.display_tree(level + 1)  # Llama recursivamente a los hijos

# Ejemplo de uso
if __name__ == "__main__":
    # Crear nodos raíz y secundarios
    root = TreeNode("Raíz")
    child1 = TreeNode("Hijo 1")
    child2 = TreeNode("Hijo 2")
    child3 = TreeNode("Hijo 3")
    
    # Agregar hijos al nodo raíz
    root.add_child(child1)
    root.add_child(child2)
    
    # Agregar nietos
    grandchild1 = TreeNode("Nieto 1")
    grandchild2 = TreeNode("Nieto 2")
    child1.add_child(grandchild1)
    child1.add_child(grandchild2)
    
    # Agregar más hijos al segundo hijo
    child2.add_child(child3)

    # Mostrar el árbol
    root.display_tree()
